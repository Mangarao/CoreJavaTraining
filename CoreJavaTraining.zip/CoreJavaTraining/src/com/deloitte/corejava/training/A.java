package com.deloitte.corejava.training;

import java.util.Scanner;

 class C{
	 
	 private class Inner{
		 
	 }
	
}

class B{
	
}

public class A {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your name");
		String uname = sc.next();
		System.out.println("Hello "+uname+", Welcome to Deloitte");

	}
	
}
