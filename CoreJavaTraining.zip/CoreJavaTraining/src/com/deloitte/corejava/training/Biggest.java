package com.deloitte.corejava.training;

public class Biggest {
	public static void main(String[] args) {
		int a=10, b=20;
		System.out.println(a>b?"a is big":"b is big");
		
		/*
		 * if(a>b) { System.out.println("a is big"); }else {
		 * System.out.println("b is big"); }
		 */
	}

}
