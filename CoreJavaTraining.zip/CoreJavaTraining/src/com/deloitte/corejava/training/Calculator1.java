package com.deloitte.corejava.training;
/**
 * This is the calculator class to perform basic aithemetic operations
 * @author marepalli
 * @since 1.0
 * @version 1.1.0
 */
public class Calculator1 {
	//below are simple methods..
	
	/**
	 * This is sum method to return sum of two given numbers
	 * @param num1
	 * @param num2
	 * @return result
	 */
	public int sum(int num1, int num2) {
		return num1+num2;
	}
	
	/**
	 * This is sub method to return sub of two given numbers
	 * @param num1
	 * @param num2
	 * @return result
	 */
	public int sub(int num1, int num2) {
		return num1-num2;
	}
	
	/**
	 * This is mul method to return product of two given numbers
	 * @param num1
	 * @param num2
	 * @return result
	 */
	public int mul(int num1, int num2) {
		return num1*num2;
	}
	
	/**
	 * This is div method to return division of two given numbers
	 * @param num1
	 * @param num2
	 * @return result
	 */
	public int div(int num1, int num2) {
		return num1/num2;
	}
	
	public static void main(String[] args) {
		//Calculator object is created
		Calculator1 c=new Calculator1();
		/*
		 * Calling the basic arithmetic methods
		 * printting the result
		 */
		System.out.println(c.sum(10,20));
		System.out.println(c.sub(10,20));
		System.out.println(c.mul(10,20));
		System.out.println(c.div(10,20));
	}

}
