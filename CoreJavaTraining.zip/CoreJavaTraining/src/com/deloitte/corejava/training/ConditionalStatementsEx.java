package com.deloitte.corejava.training;

public class ConditionalStatementsEx {

	public static void main(String[] args) {
		if (false) {
			System.out.println("statement1");
		}
		System.out.println("statement2");

	}

}
