package com.deloitte.corejava.training;

public class DatatypesEx {
	static int i;
	static double d=10.0;
	static char ch='1';
	static String name="Mihiraan";
	public static void main(String[] args) {
		i=10;
		boolean b=false;
		
		System.out.println("Boolean : "+b);
		System.out.println("Integer : "+i);
		System.out.println("Double  value: "+d);
		System.out.println("Character  value: "+ch);
		System.out.println("String default value: "+name);
		
	}

}
