package com.deloitte.corejava.training;

public class GradingEx {
	
	public static void main(String[] args) {
		char ch='A';
		switch (ch) {
		case 'A':
			System.out.println("Excellent");
			break;
			
		case 'B':
			System.out.println("Pass");
			
		case 'C':
			System.out.println("Fail");
			break;

		default:
			System.out.println("Invalid grade");
			break;
		}
		
		System.out.println("Program execution is complete");
	}
	
	

}
