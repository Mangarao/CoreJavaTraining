package com.deloitte.corejava.training;

public class HelloWorld {

	  public static void main(String bla[]) {
		// TODO Auto-generated method stub
		System.out.println("Hello world");
		System.out.println("Welcome to Deloitte");

	}

}
