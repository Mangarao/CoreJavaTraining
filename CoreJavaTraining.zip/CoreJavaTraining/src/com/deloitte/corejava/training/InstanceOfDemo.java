package com.deloitte.corejava.training;

public class InstanceOfDemo {

	public static void main(String[] args) {
		String name="Mihiraan";
		System.out.println(name instanceof Object);
		name=null;
		System.out.println(name instanceof Object);
	}

}
