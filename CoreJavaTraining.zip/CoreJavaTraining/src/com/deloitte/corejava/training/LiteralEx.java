package com.deloitte.corejava.training;

public class LiteralEx {
	public static void main(String[] args) {
		System.out.print("This is statement1\s\s");
		System.out.println("This is statement2");
	}

}
