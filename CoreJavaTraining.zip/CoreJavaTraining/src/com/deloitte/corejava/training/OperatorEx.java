package com.deloitte.corejava.training;

public class OperatorEx {
	
	public static void main(String[] args) {
		int a = 10;
		int b=a++;
		System.out.println("a="+a);
		System.out.println("b="+(--b));
		
	}

}
