package com.deloitte.corejava.training;

public class TestA {
	
	int x; //instance variable
	static int y; //static variable 
	
	public static void main(String[] args) {
		int z=10; //local variable.. 
		
		System.out.println("\"Now I become death, Destroyer of the word\"");
		
		
	}

}
