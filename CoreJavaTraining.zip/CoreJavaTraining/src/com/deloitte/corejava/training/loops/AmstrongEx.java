package com.deloitte.corejava.training.loops;
public class AmstrongEx {

	public static boolean isArmsrong(int num) {
		int temp=num;
		int sum=0;
		int rem=0;
		while(num!=0) {
			rem=num%10;
			sum+=rem*rem*rem;
			num=num/10;
		}
		System.out.println("Sum of cubes of each individaul is: "+sum);
		return sum==temp?true:false;
		}
	
	public static void main(String[] args) {
		System.out.println("isArmsrong(153) "+isArmsrong(153));
		System.out.println("isArmsrong(354) "+isArmsrong(354));
		
	}

}
