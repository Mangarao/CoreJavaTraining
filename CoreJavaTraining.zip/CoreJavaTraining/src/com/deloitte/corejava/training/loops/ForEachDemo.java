package com.deloitte.corejava.training.loops;

public class ForEachDemo {
	public static void main(String[] args) {
		String[] names= {"Manga","Mihi","Aarohi", "kohli","Rahul"};
		/*
		 * for (int i = 0; i < names.length; i++) { System.out.println(names[i]); }
		 */
		/*
		 * for (int i = 0; i < names.length; i++) { if(i==1) { names[i]="AMR"; } }
		 */
		int count=0;
		for (String name : names) {
			count++;
			System.out.println(name);
		}
		
		
	}

}
