package com.deloitte.corejava.training.loops;

public class GCD {
	
	static int getGCD(int num1, int num2) {
		int gcd=0;
		//logic
		int min=num1<num2?num1:num2;
		for (int i = min; i>=0; i--) {
			if(num1%i==0 && num2%i==0) {
				gcd=i;
				break;
			}
		}
		return gcd;
	}
	
	public static void main(String[] args) {
		System.out.println("getGCD(12,24)="+getGCD(12,24));
		System.out.println("getGCD(24,36)="+getGCD(24,36));
		System.out.println("getGCD(117,246)="+getGCD(118,246));
		//12 - 1,2,3,4,6,12
		//24- 1,2,3,4,6,8,12,24
	}

}
