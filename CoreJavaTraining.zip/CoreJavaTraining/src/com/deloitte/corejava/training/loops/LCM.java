package com.deloitte.corejava.training.loops;


public class LCM {
	static int getLCM(int num1, int num2) {
		int lcm=0;
		int max=num1>num2?num1:num2;
		while(true) {
			if(max%num1==0 && max%num2==0) {
				lcm=max;
				break;
			}else {
				max++;
			}
		}
		return lcm;
		
	}
	
	public static void main(String[] args) {
		System.out.println("LCM of 7,4= "+getLCM(7,4));
		System.out.println("LCM of 43,79= "+getLCM(43,79));
	}

	

}
