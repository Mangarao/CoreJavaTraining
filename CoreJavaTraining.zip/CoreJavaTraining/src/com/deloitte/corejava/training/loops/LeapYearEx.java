package com.deloitte.corejava.training.loops;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class LeapYearEx {
	
		public static boolean isLeap(int year) {
			if(year%400==0 || year%4==0 && year%100!=0) {
				return true;
			}
			return false;
		}
		
		
		public static void main(String[] args) {
			System.out.println(isLeap(2014));
			GregorianCalendar cal = (GregorianCalendar) GregorianCalendar.getInstance();
			if(cal.isLeapYear(2005)) {
				System.out.println("leap year");
				
			}else {
				System.out.println("Not leap year");
			}
			
		}
}
