package com.deloitte.corejava.training.loops;

public class PalindromeNumEx {
	
	public static int getReverse(int num) {
		int temp=num;
		int reverse=0;
		while(num!=0) {
			reverse = reverse*10 +(num%10);
			num=num/10;
		}
		System.out.println("reverse of the "+temp+" is:  "+reverse);
		return reverse;
	}
	
	public static boolean isPalindrome(int num) {
		return getReverse(num)==num?true:false;
	}
	
	public static void main(String[] args) {
		System.out.println("isPalindrome(123) "+isPalindrome(123));
		System.out.println("isPalindrome(123) "+isPalindrome(1221));
		
	}

}
