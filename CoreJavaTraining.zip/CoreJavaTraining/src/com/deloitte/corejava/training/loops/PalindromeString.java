package com.deloitte.corejava.training.loops;

public class PalindromeString {
	
	public static boolean isPalindrome(String str) {
		//return new StringBuffer(name).reverse().toString().equals(name);
		int length = str.length();
        for (int i = 0; i < length / 2; i++) {
            if (str.charAt(i) != str.charAt(length - 1 - i)) {
                return false;
            }
        }
        return true;
	}
	
	public static void main(String[] args) {
		System.out.println("isPalindrome(MALAYALAM): "+isPalindrome("MALAYALAM"));
		System.out.println("isPalindrome(RACECAR): "+isPalindrome("RACECAR"));
		
	}

}
