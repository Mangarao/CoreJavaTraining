package com.deloitte.corejava.training.loops;

public class PrintEven {
	
	public static void main(String[] args) {
		for (int i = 1; i <=10; i+=2) {
				System.out.println(i);
		}
	}

}
