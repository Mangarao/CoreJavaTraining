package com.deloitte.corejava.training.loops;

public class PrintHW {

	public static void main(String[] args) {
		System.out.println("Main method execution starts");
		/*
		 * for (int i = 1; i <=5; i++) { System.out.println("Hello World"); }
		 */
		/*
		 * int i=1; //initialization while (i<=5) { //condition checking
		 * System.out.println("Hello World"); i++; //variable change }
		 */
		int i=1; //initialization
		do {
			System.out.println("Hello World");
			i++;
		} while (i<=5);
		
		System.out.println("Main method execution ends");
	}
}
