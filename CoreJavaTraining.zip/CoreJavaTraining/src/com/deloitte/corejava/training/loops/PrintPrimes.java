package com.deloitte.corejava.training.loops;

public class PrintPrimes {
	
	static boolean isPrime(int num) {
		
		for(int i=2; i<=Math.sqrt(num); i++) {
			if(num%i==0) {
				return false;
			}
		}
		return true;
	}
	
	static void printPrimes(int start, int end) {
		int count=0;
		for (int i = start; i <=end; i++) {
			if(isPrime(i)) {
				count++;
				System.out.print(i+"\t");
			}
			
		}
		System.out.println("\nCount of primes: "+count);
	}
	
	public static void main(String[] args) {
		printPrimes(2, 200);
		
	}

}
