package com.deloitte.corejava.training.loops;

public class TablePrint {
	
	static void printTable(int num, int repetition) {
		for (int i = 1; i <=repetition; i++) {
			System.out.println(num+" * "+i+"="+(num*i));
		}
	}
	
	public static void main(String[] args) {
		printTable(11,20);
		System.out.println("*******");
		printTable(12,10);
		
	}

}
