package com.deloitte.corejava.training.loops;

public class TestVowels {
	
	public static boolean containsVowels(String name) {
		name = name.toUpperCase();
		for (int i = 0; i < name.length(); i++) {
			if(name.charAt(i)=='A' ||
					name.charAt(i)=='E' ||
					name.charAt(i)=='I' ||
					name.charAt(i)=='O' ||
					name.charAt(i)=='U') {
				return true;
			}
		}
		return false;
	}
	
	public static void main(String[] args) {
		System.out.println(containsVowels("MangaRao"));
		
		
	}

}
