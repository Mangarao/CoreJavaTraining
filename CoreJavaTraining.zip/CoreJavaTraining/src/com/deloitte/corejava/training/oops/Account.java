package com.deloitte.corejava.training.oops;

public class Account implements Cloneable {
	
	private int accId;
	private String name;
	private double balance;
	public Account(int accId, String name, double balance) {
		super();
		this.accId = accId;
		this.name = name;
		this.balance = balance;
		
		java.sql.Date d;
		java.util.Date d1;
	}
		
	@Override
	public String toString() {
		return accId+" "+name+" "+balance;
	}
	
	public static void main(String[] args) throws CloneNotSupportedException {
		Account a=new Account(101, "manga", 4344343);
		System.out.println(a);
		Account a1 = (Account) a.clone();
		System.out.println(a1);
	}

}
