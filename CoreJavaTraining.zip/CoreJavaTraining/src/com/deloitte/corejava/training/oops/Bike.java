package com.deloitte.corejava.training.oops;

public class Bike {
	
	Bike(){
		System.out.println("Bike is created");
	}
	
	public static void main(String[] args) {
		new Bike();
		new Bike();
	}

}
