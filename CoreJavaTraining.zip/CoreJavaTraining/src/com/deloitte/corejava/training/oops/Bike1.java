package com.deloitte.corejava.training.oops;

 class Vehicle{
	
	final static int x=10;
	final int y=20;
	
	 void run() {
		System.out.println("Vehicle is running...");
	}
}

public class Bike1 extends Vehicle{
	
	
	void run() {
		System.out.println("Bike1 is running slowly...");
	}
	
	public static void main(String[] args) {
		Bike1 b =new Bike1();
		b.run();
	}

}
