package com.deloitte.corejava.training.oops;

interface Father{
	public static final double PI=3.14;
	void m1();
	
}

interface Mother{
	void m1();
	
}

public class Child implements Father, Mother {

	@Override
	public void m1() {
		System.out.println("M1 method is implemented");
		
	}

	public static void main(String[] args) {
		Child c=new Child();
		c.m1();
		
		System.out.println("PI value: "+c.PI);
	}
}
