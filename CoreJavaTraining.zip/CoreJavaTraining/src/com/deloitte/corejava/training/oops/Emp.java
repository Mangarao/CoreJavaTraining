package com.deloitte.corejava.training.oops;

public class Emp {
	Emp(){
		System.out.println("Emp constructor");
	}
	
	 private float salary=50000;
	 
	 public float getSalary() {
		 return salary;
	 }
	 
	 void sayHi() {
		 System.out.println("Hi from EMP");
	 }

}
