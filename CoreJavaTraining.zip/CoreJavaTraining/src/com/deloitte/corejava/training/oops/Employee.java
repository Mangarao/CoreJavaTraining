package com.deloitte.corejava.training.oops;

public class Employee {
	
	private int id;
	private String name;
	
	public void setEmpData(int i, String n) {
		id=i;
		name=n;
	}
	
	public void displayEmpDetails() {
		System.out.println("Id: "+id+" Name: "+name);
	}
	
	 public static void main(String[] args) {
		Employee e1 =new Employee();
		e1.setEmpData(101, "Manga");
		e1.displayEmpDetails();
		Employee e2=new Employee();
		e2.setEmpData(102,"Mihiraan");
		e2.displayEmpDetails();
	}

}
