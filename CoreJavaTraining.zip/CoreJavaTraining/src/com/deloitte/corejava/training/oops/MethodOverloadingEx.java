package com.deloitte.corejava.training.oops;

public class MethodOverloadingEx {
	
	void sum(int num1, int num2) {
		System.out.printf("sum of num1 %d, num2 %d=%d: ", num1, num2, (num1+num2));
	}
	
	void sum(int num1, int num2, int num3) {
		System.out.printf("Method with 3 parameters: "+ (num1+num2+num3));
	}
	
	void prod(int num1, long num2) {
		System.out.println(num1*num2);
	}
	
	void prod(long num1, int num2) {
		System.out.println(num1*num2);
	}
	
	public static void main(Integer[] args) {
		System.out.println("Main method is overloaded");
	}
	public static void main(String... args) {
		MethodOverloadingEx m=new MethodOverloadingEx();
		m.sum(10, 20);
		m.sum(10,20,30);
		m.prod(20L, 20);
		main(new Integer[] {});
		
	}

}
