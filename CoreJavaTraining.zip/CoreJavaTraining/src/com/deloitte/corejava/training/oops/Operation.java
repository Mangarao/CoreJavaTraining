package com.deloitte.corejava.training.oops;

public class Operation {

	int data = 50;
	
	public void change(Operation op) {
		op.data=op.data+100;
		System.out.println("data in change: "+data);
	}
	
	public static void main(String[] args) {
		Operation o1=new Operation();
		System.out.println("before change method: "+o1.data);
		o1.change(o1);
		System.out.println("after change method execution: "+o1.data);
	}

}
