package com.deloitte.corejava.training.oops;

public class Programmer extends Emp {
	
	Programmer(){
		super();
		System.out.println("Programmer constructor");
	}
	
	private float bonus=20000;
	
	public static void main(String[] args) {
		Programmer p = new Programmer();
		System.out.println("Net salary: "+ 
		(p.getSalary()+p.bonus));
		p.sayHi();
	}

}
