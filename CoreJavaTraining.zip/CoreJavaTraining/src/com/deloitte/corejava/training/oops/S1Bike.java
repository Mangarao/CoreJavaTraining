package com.deloitte.corejava.training.oops;

abstract class Ola{
	abstract void run();
	
	void m2() {
		System.out.println("m2 method..");
	}
}

public class S1Bike extends Ola {

	@Override
	void run() {
		System.out.println("Electric bike is running without pollution.");
	}

	public static void main(String[] args) {
		Ola o=new S1Bike();
		o.run();
		o.m2();
	}
}
