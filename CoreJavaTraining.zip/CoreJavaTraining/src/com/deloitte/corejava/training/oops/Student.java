package com.deloitte.corejava.training.oops;

public class Student {
	
	private int id;
	private String name;
	
	Student(){
		
	}
	Student(int i){
		
	}
	Student(int i, String n){
		id=i;
		name=n;
	}
	
	public void displayStudent() {
		System.out.println(id+" "+name);
	}
	
	public static void main(String[] args) {
		Student s1=new Student(101, "Manga");
		s1.displayStudent();
		Student s2=new Student(102, "Kohli");
		s2.displayStudent();
	}

}
