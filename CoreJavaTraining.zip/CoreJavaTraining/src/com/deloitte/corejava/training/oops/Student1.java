package com.deloitte.corejava.training.oops;
public class Student1 {
	private int id;
	private String name;
	public Student1() {
		//this(10,"AMR");
	System.out.println("Default constructor is called");
	}

	public Student1(int i) {
		this();
		
	}
	public Student1(int i, String n) {
		this();
		System.out.println("2 parameterized constructor is called");
		this.id = i;
		this.name = n;
	}
	
	public void sayHi() {
		System.out.println("Hi...");
	}
	public void displayStudent() {
		this.sayHi();
		System.out.println(id+" "+name);
	}
	public static void main(String[] args) {
		Student1 s2=new Student1();
		Student1 s1=new Student1(101, "Mihi");
		s1.displayStudent();
		/*
		 * Student1 s2=new Student1(102,"Aarohi"); s2.displayStudent();
		 */
	}
}
