package com.deloitte.corejava.training.oops;

public class TestAccount {
	
	public static void main(String[] args) {
		Account a= new Account(101, "Manga", 1000000.34d);
		System.out.println(a.toString());
		//a.clo
	}

}
