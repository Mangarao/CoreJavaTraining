package com.deloitte.corejava.training.oops;

class Bank {
	protected float getRateOfInterest() {
		return 7.0f;
	}
}

class SBI extends Bank {
	@Override
	protected float getRateOfInterest() {
		return 8.5f;
	}
}

class AXIS extends Bank {
	@Override
	public float getRateOfInterest() {
		return 9.5f;
	}

}

class ICICI extends Bank {
	@Override
	public float getRateOfInterest() {
		return 9.0f;
	}
	
	public void m1() {
		System.out.println("m1 method");
	}
}

public class TestBank {

	public static void main(String[] args) {
			Bank s=new SBI();
			Bank i=new ICICI();
			//i.m1();
			Bank a=new AXIS();
			System.out.println("SBI ROI: "+s.getRateOfInterest());
			System.out.println("AXIS ROI: "+a.getRateOfInterest());
			System.out.println("ICICI ROI: "+i.getRateOfInterest());
	}

}
