package com.deloitte.corejava.training.oops;

interface Vehicle1{
	public abstract void run();
	
}
public class TestBike implements Vehicle1{

	@Override
	public void run() {
		System.out.println("Bike test run is happening");
		
	}
	
	public static void main(String[] args) {
		new TestBike().run();
	}

}
