package com.deloitte.corejava.training.oops;

public class TestInstance {
	
	final int speedlimit=200;
	
	/*
	 * static { System.out.println("static block"); }
	 */
	
	{
		
		System.out.println("Instance block");
		new TestInstance();
	}
	
	/*
	 * public TestInstance() { System.out.println("Constructoor"); }
	 */
	
	public static void main(String[] args) {
		new TestInstance();
	}

}
