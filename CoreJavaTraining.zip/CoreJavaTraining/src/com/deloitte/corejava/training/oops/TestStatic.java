package com.deloitte.corejava.training.oops;



public class TestStatic { 
	
	static void m1() {
		
		
	}
	static class A1{
		static int x=10;
		
	}
	static TestStatic t = new TestStatic();
	static int x=10;
	
	/*
	 * void sayHi() { x=20; }
	 */
	
	static {
		t.x=20;
		System.out.println("static blocked executed: "+t.x);
	}
	public static void main(String[] args) {
		System.out.println("Main method executed");
		System.out.println(TestStatic.A1.x);
	}

}
