package com.deloitte.corejava.training.oops;

import java.util.ArrayList;
import java.util.List;

public class VarArgDemo {
	
	void sum(List... nums) {
		
	}
	void sum(int... nums) {
		int sum=0;
		for (int i = 0; i < nums.length; i++) {
			sum+=nums[i];
		}
		System.out.printf("Sum is: %d \n", sum);
	}

	public static void main(String[] args) {
		VarArgDemo v=new VarArgDemo();
		v.sum(new int[] {10,20});
		v.sum(new int[] {10,20,30});
		v.sum(new ArrayList());
		v.sum(new int[] {10,20,30,40,50});
	}
}
