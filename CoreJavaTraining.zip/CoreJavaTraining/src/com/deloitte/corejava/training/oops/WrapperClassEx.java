package com.deloitte.corejava.training.oops;

public class WrapperClassEx {
	
	public static void main(String[] args) {
		int i=10;
		Integer i1=i; //auto boxing
		i1=Integer.valueOf(i);
		
		Double d1=new Double(10.02);
		double d=d1; //auto unboxing
		
		
	}

}
